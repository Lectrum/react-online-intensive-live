// Core
import styled from 'styled-components';

export const Heading = styled.h1`
    user-select: none;
    margin-bottom: 30px;
    color: oliveDrab;
    font-weight: 700;
    font-size: 44px;
`;
